/*
 * Copyright 2022 Stax
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hover.momopay.channels

import android.content.Context
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequest
import androidx.work.PeriodicWorkRequest
import androidx.work.Worker
import androidx.work.WorkerParameters
import com.hover.momopay.R
import com.hover.momopay.database.AppDatabase
import java.io.IOException
import java.util.concurrent.TimeUnit
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import timber.log.Timber

class UpdateChannelsWorker(context: Context, params: WorkerParameters) : Worker(context, params) {

    private val client = OkHttpClient()
    private val channelDao = AppDatabase.getInstance(context).channelDao()

    override fun doWork(): Result {
        return try {
            val channelsJson = downloadChannels(url)
            if (channelsJson != null) {
                val data: JSONArray = channelsJson.getJSONArray("data")
                Channel.load(data, channelDao, applicationContext)
                Timber.v("Successfully Updated channels")
                Result.success()
            } else {
                Timber.d("Failed to update channels")
                Result.failure()
            }
        } catch (e: JSONException) {
            Result.failure()
        } catch (e: NullPointerException) {
            Result.failure()
        } catch (e: IOException) {
            Result.retry()
        }
    }

    private val url get() = applicationContext.getString(R.string.maathai_api_url).plus(applicationContext.getString(R.string.channels_endpoint))

    private fun downloadChannels(url: String): JSONObject? {
        val request: Request = Request.Builder().url(url).build()
        val response: Response = client.newCall(request).execute()
        return response.body?.let { JSONObject(it.string()) }
    }

    companion object {
        const val CHANNELS_WORK_ID = "CHANNELS"
        const val TAG = "UpdateChannelsWorker"

        private val netConstraint = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

        fun makeToil(): PeriodicWorkRequest {
            return PeriodicWorkRequest.Builder(UpdateChannelsWorker::class.java, 7, TimeUnit.DAYS)
                .setConstraints(netConstraint)
                .build()
        }

        fun makeWork(): OneTimeWorkRequest {
            return OneTimeWorkRequest.Builder(UpdateChannelsWorker::class.java)
                .setConstraints(netConstraint)
                .build()
        }
    }
}