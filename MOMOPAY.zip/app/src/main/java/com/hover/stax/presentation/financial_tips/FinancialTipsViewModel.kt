/*
 * Copyright 2022 Stax
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hover.momopay.presentation.financial_tips

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.hover.momopay.domain.model.Resource
import com.hover.momopay.domain.use_case.financial_tips.TipsUseCase
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach

class FinancialTipsViewModel(private val tipsUseCase: TipsUseCase) : ViewModel() {

    private val _tipsState = MutableStateFlow(FinancialTipsState())
    val tipsState = _tipsState.asStateFlow()

    init {
        getTips()
    }

    fun getTips() = tipsUseCase().onEach { result ->
        when (result) {
            is Resource.Loading -> _tipsState.value = FinancialTipsState(isLoading = true)
            is Resource.Error -> _tipsState.value = FinancialTipsState(error = result.message ?: "An unexpected error occurred", isLoading = false)
            is Resource.Success -> _tipsState.value = FinancialTipsState(tips = result.data ?: emptyList(), isLoading = false)
        }
    }.launchIn(viewModelScope)
}