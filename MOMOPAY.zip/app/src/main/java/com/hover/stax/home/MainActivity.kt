/*
 * Copyright 2022 Stax
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hover.momopay.home

import android.content.Intent
import android.os.Bundle
import androidx.navigation.NavDirections
import com.hover.sdk.actions.HoverAction
import com.hover.sdk.api.Hover
import com.hover.sdk.permissions.PermissionHelper
import com.hover.momopay.FRAGMENT_DIRECT
import com.hover.momopay.MainNavigationDirections
import com.hover.momopay.R
import com.hover.momopay.databinding.ActivityMainBinding
import com.hover.momopay.login.AbstractGoogleAuthActivity
import com.hover.momopay.notifications.PushNotificationTopicsInterface
import com.hover.momopay.presentation.financial_tips.FinancialTipsFragment
import com.hover.momopay.requests.NewRequestViewModel
import com.hover.momopay.requests.REQUEST_LINK
import com.hover.momopay.requests.RequestSenderInterface
import com.hover.momopay.requests.SMS
import com.hover.momopay.settings.BiometricChecker
import com.hover.momopay.transactions.TransactionHistoryViewModel
import com.hover.momopay.transfers.TransferViewModel
import com.hover.momopay.utils.AnalyticsUtil
import com.hover.momopay.utils.UIHelper
import com.hover.momopay.utils.Utils
import com.hover.momopay.views.StaxDialog
import org.koin.androidx.viewmodel.ext.android.viewModel
import timber.log.Timber

class MainActivity : AbstractGoogleAuthActivity(), BiometricChecker.AuthListener, PushNotificationTopicsInterface, RequestSenderInterface {

    lateinit var navHelper: NavHelper

    private val transferViewModel: TransferViewModel by viewModel()
    private val requestViewModel: NewRequestViewModel by viewModel()
    private val historyViewModel: TransactionHistoryViewModel by viewModel()

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        navHelper = NavHelper(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        navHelper.setUpNav()

        initFromIntent()
        checkForRequest(intent)
        checkForFragmentDirection(intent)
        observeForAppReview()
        setGoogleLoginInterface(this)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        checkForRequest(intent!!)
        checkForFragmentDirection(intent)
    }

    override fun onResume() {
        super.onResume()
        navHelper.setUpNav()
    }

    fun checkPermissionsAndNavigate(navDirections: NavDirections) {
        navHelper.checkPermissionsAndNavigate(navDirections)
    }

    private fun observeForAppReview() = historyViewModel.showAppReviewLiveData().observe(this@MainActivity) {
        if (it) StaxAppReview.launchStaxReview(this@MainActivity)
    }

    private fun checkForRequest(intent: Intent) {
        if (intent.hasExtra(REQUEST_LINK)) {
            createFromRequest(intent.getStringExtra(REQUEST_LINK)!!)
        }
    }

    private fun checkForFragmentDirection(intent: Intent) {
        if (intent.hasExtra(FRAGMENT_DIRECT)) {
            val toWhere = intent.extras!!.getInt(FRAGMENT_DIRECT, 0)

            if (toWhere == NAV_EMAIL_CLIENT)
                Utils.openEmail(getString(R.string.stax_emailing_subject, Hover.getDeviceId(this)), this)
            else
                navHelper.checkPermissionsAndNavigate(toWhere)
        }
    }

    private fun initFromIntent() {
        when {
            intent.hasExtra(REQUEST_LINK) -> createFromRequest(intent.getStringExtra(REQUEST_LINK)!!)
            intent.hasExtra(FinancialTipsFragment.TIP_ID) -> navHelper.navigateWellness(intent.getStringExtra(FinancialTipsFragment.TIP_ID)!!)
            else -> AnalyticsUtil.logAnalyticsEvent(getString(R.string.visit_screen, intent.action), this)
        }
    }

    private fun createFromRequest(link: String) {
        navHelper.checkPermissionsAndNavigate(MainNavigationDirections.actionGlobalTransferFragment(HoverAction.P2P))
        addLoadingDialog()
        transferViewModel.load(link)
        AnalyticsUtil.logAnalyticsEvent(getString(R.string.clicked_request_link), this)
    }

    private fun addLoadingDialog() {
        val alertDialog = StaxDialog(this).setDialogMessage(R.string.loading_link_dialoghead).showIt()
        transferViewModel.isLoading.observe(this@MainActivity) { if (!it) alertDialog?.dismiss() }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS && PermissionHelper(this).permissionsGranted(grantResults)) {
            AnalyticsUtil.logAnalyticsEvent(getString(R.string.perms_sms_granted), this)
            sendSms(requestViewModel, this)
        } else if (requestCode == SMS) {
            AnalyticsUtil.logAnalyticsEvent(getString(R.string.perms_sms_denied), this)
            UIHelper.flashAndReportMessage(this, getString(R.string.toast_error_smsperm))
        }
    }

    override fun onAuthError(error: String) {
        Timber.e("Error : $error")
    }

    override fun onAuthSuccess(action: HoverAction?) {
        Timber.v("Auth success on action: ${action?.public_id}")
    }
}