/*
 * Copyright 2022 Stax
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.hover.momopay.di

import androidx.datastore.core.handlers.ReplaceFileCorruptionHandler
import androidx.datastore.preferences.SharedPreferencesMigration
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.preferencesDataStoreFile
import com.hover.sdk.database.HoverRoomDatabase
import com.hover.momopay.accounts.AccountDetailViewModel
import com.hover.momopay.accounts.AccountsViewModel
import com.hover.momopay.actions.ActionSelectViewModel
import com.hover.momopay.addChannels.ChannelsViewModel
import com.hover.momopay.contacts.ContactRepo
import com.hover.momopay.data.local.SimRepo
import com.hover.momopay.data.local.accounts.AccountRepo
import com.hover.momopay.data.local.actions.ActionRepo
import com.hover.momopay.data.local.channels.ChannelRepo
import com.hover.momopay.data.local.parser.ParserRepo
import com.hover.momopay.data.remote.StaxApi
import com.hover.momopay.data.repository.AccountRepositoryImpl
import com.hover.momopay.data.repository.AuthRepositoryImpl
import com.hover.momopay.data.repository.BountyRepositoryImpl
import com.hover.momopay.data.repository.ChannelRepositoryImpl
import com.hover.momopay.data.repository.FinancialTipsRepositoryImpl
import com.hover.momopay.database.AppDatabase
import com.hover.momopay.domain.repository.AccountRepository
import com.hover.momopay.domain.repository.AuthRepository
import com.hover.momopay.domain.repository.BountyRepository
import com.hover.momopay.domain.repository.ChannelRepository
import com.hover.momopay.domain.repository.FinancialTipsRepository
import com.hover.momopay.domain.use_case.bounties.GetChannelBountiesUseCase
import com.hover.momopay.domain.use_case.financial_tips.TipsUseCase
import com.hover.momopay.domain.use_case.sims.ListSimsUseCase
import com.hover.momopay.domain.use_case.stax_user.StaxUserUseCase
import com.hover.momopay.faq.FaqViewModel
import com.hover.momopay.futureTransactions.FutureViewModel
import com.hover.momopay.inapp_banner.BannerViewModel
import com.hover.momopay.ktor.EnvironmentProvider
import com.hover.momopay.ktor.KtorClientFactory
import com.hover.momopay.languages.LanguageViewModel
import com.hover.momopay.login.LoginViewModel
import com.hover.momopay.merchants.MerchantRepo
import com.hover.momopay.merchants.MerchantViewModel
import com.hover.momopay.paybill.PaybillRepo
import com.hover.momopay.paybill.PaybillViewModel
import com.hover.momopay.preferences.DefaultSharedPreferences
import com.hover.momopay.preferences.DefaultTokenProvider
import com.hover.momopay.preferences.LocalPreferences
import com.hover.momopay.preferences.TokenProvider
import com.hover.momopay.presentation.bounties.BountyViewModel
import com.hover.momopay.presentation.financial_tips.FinancialTipsViewModel
import com.hover.momopay.presentation.home.BalancesViewModel
import com.hover.momopay.presentation.home.HomeViewModel
import com.hover.momopay.presentation.sims.SimViewModel
import com.hover.momopay.requests.NewRequestViewModel
import com.hover.momopay.requests.RequestDetailViewModel
import com.hover.momopay.requests.RequestRepo
import com.hover.momopay.schedules.ScheduleDetailViewModel
import com.hover.momopay.schedules.ScheduleRepo
import com.hover.momopay.transactionDetails.TransactionDetailsViewModel
import com.hover.momopay.transactions.TransactionHistoryViewModel
import com.hover.momopay.transactions.TransactionRepo
import com.hover.momopay.transfers.TransferViewModel
import io.ktor.client.engine.android.Android
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import org.koin.android.ext.koin.androidApplication
import org.koin.android.ext.koin.androidContext
import org.koin.androidx.viewmodel.dsl.viewModelOf
import org.koin.core.module.dsl.bind
import org.koin.core.module.dsl.factoryOf
import org.koin.core.module.dsl.singleOf
import org.koin.core.qualifier.named
import org.koin.dsl.module

const val TIMEOUT = 10_000

val appModule = module {
    viewModelOf(::FaqViewModel)
    viewModelOf(::ActionSelectViewModel)
    viewModelOf(::ChannelsViewModel)
    viewModelOf(::AccountsViewModel)
    viewModelOf(::AccountDetailViewModel)
    viewModelOf(::NewRequestViewModel)
    viewModelOf(::TransferViewModel)
    viewModelOf(::ScheduleDetailViewModel)
    viewModelOf(::BalancesViewModel)
    viewModelOf(::TransactionHistoryViewModel)
    viewModelOf(::BannerViewModel)
    viewModelOf(::FutureViewModel)
    viewModelOf(::LoginViewModel)
    viewModelOf(::TransactionDetailsViewModel)
    viewModelOf(::LanguageViewModel)
    viewModelOf(::BountyViewModel)
    viewModelOf(::FinancialTipsViewModel)
    viewModelOf(::PaybillViewModel)
    viewModelOf(::MerchantViewModel)
    viewModelOf(::RequestDetailViewModel)

    viewModelOf(::HomeViewModel)
    viewModelOf(::SimViewModel)
}

val dataModule = module {
    single { AppDatabase.getInstance(androidApplication()) }
    single { HoverRoomDatabase.getInstance(androidApplication()) }
    single { get<AppDatabase>().userDao() }

    singleOf(::TransactionRepo)
    singleOf(::ChannelRepo)
    singleOf(::ActionRepo)
    singleOf(::ContactRepo)
    singleOf(::AccountRepo)
    singleOf(::RequestRepo)
    singleOf(::ScheduleRepo)
    singleOf(::PaybillRepo)
    singleOf(::MerchantRepo)
    singleOf(::ParserRepo)
    singleOf(::SimRepo)

    singleOf(::StaxApi)
}

val ktorModule = module {

    single { EnvironmentProvider(androidApplication(), get()) }

    single {
        KtorClientFactory(get(), get()).create(
            Android.create {
                connectTimeout = TIMEOUT
            }
        )
    }
}

val datastoreModule = module {
    single {
        PreferenceDataStoreFactory.create(
            corruptionHandler = ReplaceFileCorruptionHandler(
                produceNewData = { emptyPreferences() }
            ),
            migrations = listOf(
                SharedPreferencesMigration(
                    androidContext(),
                    sharedPreferencesName = "stax.datastore"
                )
            ),
            scope = CoroutineScope(Dispatchers.IO + SupervisorJob()),
            produceFile = { androidContext().preferencesDataStoreFile(name = "stax.datastore") }
        )
    }
}

val repositories = module {
    single(named("CoroutineDispatcher")) {
        Dispatchers.IO
    }

    single<TokenProvider> { DefaultTokenProvider(get()) }
    single<LocalPreferences> { DefaultSharedPreferences(androidApplication()) }

    single<AccountRepository> { AccountRepositoryImpl(get(), get(), get()) }
    single<BountyRepository> { BountyRepositoryImpl(get(), get(named("CoroutineDispatcher"))) }

    singleOf(::FinancialTipsRepositoryImpl) { bind<FinancialTipsRepository>() }
    singleOf(::ChannelRepositoryImpl) { bind<ChannelRepository>() }

    singleOf(::AuthRepositoryImpl) { bind<AuthRepository>() }
}

val useCases = module {
    single(named("CoroutineDispatcher")) {
        Dispatchers.IO
    }
    single { ListSimsUseCase(get(), get(), get(), get(named("CoroutineDispatcher"))) }

    factoryOf(::TipsUseCase)

    factoryOf(::GetChannelBountiesUseCase)

    singleOf(::StaxUserUseCase)
}